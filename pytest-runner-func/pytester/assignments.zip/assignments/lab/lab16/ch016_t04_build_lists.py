evens_to_50 = [i for i in range(51) if i % 2 == 0]
print(evens_to_50)

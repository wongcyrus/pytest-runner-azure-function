my_list = list(range(16))
print(list(filter(lambda x: x % 3 == 0, my_list)))

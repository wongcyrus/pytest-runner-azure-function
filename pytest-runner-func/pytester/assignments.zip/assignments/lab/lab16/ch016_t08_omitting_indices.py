my_list = list(range(1, 11))  # List of numbers 1 - 10

# Add your code below!

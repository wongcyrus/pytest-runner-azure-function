response = None

answer = "Left"
if answer == "Left":
    print("This is the Verbal Abuse Room, you heap of parrot droppings!")

# Will the above print statement print to the console?
# Set response to 'Y' if you think so, and 'N' if you think not.

def greater_less_equal_5(answer: int) -> int:
    if None:
        return 1
    elif None:
        return -1
    else:
        return 0


print(greater_less_equal_5(4))
print(greater_less_equal_5(5))
print(greater_less_equal_5(6))

answer = "'Tis but a scratch!"


def black_knight() -> bool:
    if answer == "'Tis but a scratch!":
        return True
    else:
        return  # Make sure this returns False


def french_soldier() -> bool:
    if answer == "Go away, or I shall taunt you a second time!":
        return True
    else:
        return  # Make sure this returns False

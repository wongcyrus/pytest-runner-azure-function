# Use boolean expressions as appropriate on the lines below!

# Make me false!
bool_one = (2 <= 2) and "Alpha" == "Bravo"  # We did this one for you!

# Make me true!
bool_two = None

# Make me false!
bool_three = None

# Make me true!
bool_four = None

# Make me true!
bool_five = None

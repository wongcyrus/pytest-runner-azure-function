# Set maximum to the max value of any set of numbers on line 3!

maximum = None

print(maximum)

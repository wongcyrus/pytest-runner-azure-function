def power():  # Add your parameters here!
    result = base ** exponent
    print("%d to the power of %d is %d." % (base, exponent, result))


power()  # Add your arguments here!

# Print out the types of an integer, a float,
# and a string on separate lines below.

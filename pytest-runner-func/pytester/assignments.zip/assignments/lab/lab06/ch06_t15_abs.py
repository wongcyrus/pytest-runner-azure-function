absolute = None

print(absolute)

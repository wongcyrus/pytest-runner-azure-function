names = ["Adam", "Alex", "Mariah", "Martine", "Columbus"]

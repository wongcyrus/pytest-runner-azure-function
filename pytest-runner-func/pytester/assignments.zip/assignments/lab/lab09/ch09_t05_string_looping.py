for letter in "Codecademy":
    print(letter)

# Empty lines to make the output pretty
print()
print()

word = "Programming is fun!"

for letter in word:
    # Only print out the letter i
    if letter == "i":
        print(letter)

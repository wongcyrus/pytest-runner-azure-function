# # Establish a dictionary which translates 'cat', 'dog', and 'mouse' into French.
# en_to_fr = {XXXX}
#
# # Add 'snake' to it.
# en_to_fr[XXXX] = XXXX
#
# # Print the dictionary
# print(en_to_fr)

number = 1025

while number > 1024:
    print(number)
    number *= 2

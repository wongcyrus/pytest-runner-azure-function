message = input('Yes? ')
print(message)

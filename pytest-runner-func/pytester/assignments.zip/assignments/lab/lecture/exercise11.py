numbers = [5, 7, 11, 13, 17, 19, 29, 31]
print(numbers)

numbers[1] = 3
print(numbers)

del numbers[3]
print(numbers)

numbers[3] = 37
print(numbers)

numbers[4] = numbers[5]
print(numbers)

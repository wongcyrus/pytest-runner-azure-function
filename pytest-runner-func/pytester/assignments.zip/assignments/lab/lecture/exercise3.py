text = input('XXXX')
number = None
print(2.5 + number)

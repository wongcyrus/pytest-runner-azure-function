if False:
    print('Hello, world!')
else:
    print('Goodbye, world!')

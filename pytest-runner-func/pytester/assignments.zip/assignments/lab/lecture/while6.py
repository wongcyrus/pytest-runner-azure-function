text = 'OK'

while text != '':
    text = input('Give me some text: ')
    print(text)

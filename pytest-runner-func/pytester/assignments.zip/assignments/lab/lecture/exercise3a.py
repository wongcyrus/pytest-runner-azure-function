text = input('How much? ')
number = float(text)
print(2.5 + number)

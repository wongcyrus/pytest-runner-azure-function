if 17 < 15 + 9 and 'cat' < 'bat' and 'green' < 'groan':
    print('alpha')
else:
    print('beta')

filename = input('File name? ')
data = open(filename, 'r')

n_lines = 0
n_words = 0
n_chars = 0

# for line in XXXX:
#     n_lines += XXXX
#
#     words_in_line = line.XXXX()
#     n_words += XXXX
#
#     n_chars += XXXX
#
# data.XXXX()
print(filename, n_lines, n_words, n_chars)

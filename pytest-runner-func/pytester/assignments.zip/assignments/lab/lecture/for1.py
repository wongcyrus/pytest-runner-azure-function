words = 'The cat sat on the mat.'.split()

for word in words:
    print(word)

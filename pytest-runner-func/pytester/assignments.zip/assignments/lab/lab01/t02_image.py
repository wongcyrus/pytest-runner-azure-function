import os
from google.cloud import vision

from lab.lab01.t01_bucket import upload_file_to_bucket

# Reference https://codelabs.developers.google.com/codelabs/cloud-vision-api-python#0


def prepare_image(bucket_name: str, image_file_path: str):
    pass


def count_dog_and_cat(bucket_name: str, image_file_path: str, score: float):
    pass


def get_text_from_image(bucket_name: str, image_file_path: str):
    pass


def get_emotional_index(bucket_name: str, image_file_path: str):
    pass

float_1 = 0.25
float_2 = 40.0

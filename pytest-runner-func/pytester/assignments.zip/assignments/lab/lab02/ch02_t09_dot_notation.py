ministry = "The Ministry of Silly Walks"

print()
print()

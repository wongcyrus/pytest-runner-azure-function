# Assign your variables below, each on its own line!


# Put your variables above this line, and uncomment the following 3 line of codes.
# print(caesar)
# print(praline)
# print(viking)

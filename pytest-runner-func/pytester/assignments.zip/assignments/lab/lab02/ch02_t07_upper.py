parrot = "norwegian blue"

print()

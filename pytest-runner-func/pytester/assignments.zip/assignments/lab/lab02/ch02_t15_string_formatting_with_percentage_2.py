name = input("What is your name? ")
quest = input("What is your quest? ")
color = input("What is your favorite color? ")

# Uncomment the below 2 line of code!
# print("Ah, so your name is ___, your quest is ___, "
# "and your favorite color is ___." ___ (name, quest, color))

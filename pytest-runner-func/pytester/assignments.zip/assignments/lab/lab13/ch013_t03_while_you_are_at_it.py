num = 1

while False:  # Fill in the condition
    pass
# Print num squared
# Increment num (make sure to do this!)

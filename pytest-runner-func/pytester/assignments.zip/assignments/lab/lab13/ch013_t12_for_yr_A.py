phrase = "A bird in the hand..."

# Add your for loop


# Don't delete this print statement!
print()

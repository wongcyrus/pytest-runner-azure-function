count = 0

while count < 10:  # Add a colon
    print(count)
    # Increment count

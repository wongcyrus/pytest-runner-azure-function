choice = input('Enjoying the course? (y/n)')

while False:  # Fill in the condition (before the colon)
    choice = input("Sorry, I didn't catch that. Enter again: ")

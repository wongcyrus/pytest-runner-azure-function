import os
file_path_name = os.path.join(os.path.dirname(
    os.path.abspath(__file__)), "inputs/ch20_t04o_output.txt")

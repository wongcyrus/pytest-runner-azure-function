backpack = ['xylophone', 'dagger', 'tent', 'bread loaf']

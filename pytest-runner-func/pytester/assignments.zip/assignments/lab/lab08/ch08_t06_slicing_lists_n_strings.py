animals = "catdogfrog"

# The first three characters of animals
cat = None

# The fourth through sixth characters
dog = None

# From the seventh character to the end
frog = None

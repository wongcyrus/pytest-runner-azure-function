n = ["Michael", "Lieberman"]
# Add your function here


# print(join_strings(n))

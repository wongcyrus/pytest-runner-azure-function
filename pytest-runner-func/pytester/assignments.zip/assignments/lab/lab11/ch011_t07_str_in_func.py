n = "Hello"
# Your function here!


# print(string_function(n))

n = [3, 5, 7]

for i in range(0, len(n)):
    print(n[i])

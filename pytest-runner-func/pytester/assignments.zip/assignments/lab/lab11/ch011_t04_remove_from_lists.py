n = [1, 3, 5]
# Remove the first item in the list here

print(n)

print(bin(1))

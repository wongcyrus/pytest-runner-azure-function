class Animal(object):
    pass

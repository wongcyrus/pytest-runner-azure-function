class Triangle(object):
    def __init__(self, angle1: int, angle2: int, angle3: int):
        self.angle1 = angle1
        self.angle2 = angle2
        self.angle3 = angle3

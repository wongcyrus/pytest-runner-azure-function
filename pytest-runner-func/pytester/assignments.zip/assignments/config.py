STUDENT_ID = "979785543131"
API_KEY = ""

API_ENDPOINT = 'https://api-pytest-runner-azure-2223.azure-api.net'
LOCATIONS = "asia-east2"
PROJECT_ID = "ite3101-assignment"

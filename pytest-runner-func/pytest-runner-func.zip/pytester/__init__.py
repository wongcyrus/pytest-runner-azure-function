import logging
import subprocess
import azure.functions as func
import zipfile
import tempfile
import shutil
import os
import logging
from pathlib import Path


def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info("start")
    your_message = req.params.get("message")

    with tempfile.TemporaryDirectory() as tmpdirname:
        logging.info(tmpdirname)
        zipped_pyTest_code = os.path.join(os.path.dirname(
            os.path.realpath(__file__)), 'assignments.zip')
        file = zipfile.ZipFile(zipped_pyTest_code)
        file.extractall(path=tmpdirname)
        logging.info("extractall")

        assignment_path = os.path.join(tmpdirname, "assignments")
        virtual_env_path = os.path.join(tmpdirname, "assignments", ".venv")
        activate_virtual_env_path = os.path.join(tmpdirname, "assignments", ".venv","bin","activate")
        pip_virtual_env_path = os.path.join(tmpdirname, "assignments", ".venv","bin","pip")
        os.chdir(assignment_path)
        test_result = subprocess.getoutput(
            f'python -m venv {virtual_env_path}')
        logging.info(test_result)
        test_result = subprocess.getoutput(
            f'{pip_virtual_env_path} install -r requirements.txt')
        logging.info(test_result)          
             
        test_result_json = os.path.join(tmpdirname, 'result.json')        
        cmd = f""". {activate_virtual_env_path}
python -m pytest --json-report --json-report-file={test_result_json}
"""
        test_result = subprocess.getoutput(cmd)
        logging.info(test_result)
        test_result_json = Path(test_result_json).read_text()
        logging.info(test_result_json)
        shutil.rmtree(tmpdirname)

    if "hello" in your_message.lower() or "world" in your_message.lower():
        return func.HttpResponse(body='{ "error": "Think of a better message" }', status_code=422)

    return func.HttpResponse(body=test_result_json, status_code=200)
